# Sur le quai · livraison de démonstration · v001

Animatique 15 s, 640 × 360 à 24 i/s. Les dessins de layout sont des rendus d’origine du cours. Le mix et les sous-titres sont fournis pour répéter une livraison. Le master Matroska FFV1 conserve la sortie d’image de cette animatique sans perte de compression. Le WAV est séparé. La copie de revue utilise H.264/AAC.

Après extraction, ouvrez Projet/sur_le_quai_animatique.blend dans Blender 5.3. Ses trois images et son son se trouvent dans le même dossier. Lire le master et la revue. Comparer les départs d’images 1, 121 et 217. Le premier SRT décrit le geste et le second correspond au départ du clic à 9 s. Consulter MANIFEST.json si une pièce ne correspond pas à la livraison.

Crédits et provenance. Visuels, son synthétisé et textes créés pour Blender Cinema Master Academy. Ressources originales fournies pour la pratique du cursus.
